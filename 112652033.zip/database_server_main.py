from database_server import DatabaseServer
server = DatabaseServer()
server.start(host="127.0.0.1", port=21354)
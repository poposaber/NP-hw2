from lobby_server import LobbyServer

server = LobbyServer()
server.start(host="0.0.0.0", port=21354)